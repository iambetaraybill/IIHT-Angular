﻿using System;
using System.Diagnostics;
using System.Threading;

namespace Assignment2
{
    class PainterPartitionProblem
    {
        static int sum(int[] arr, int from, int to)
        {
            int total = 0;
            for (int i = from; i <= to; i++)
                total += arr[i];
            return total;
        }
        static int DivideAndConquerApproach(int[] arr, int n, int k)
        {
            if (k == 1)
                return sum(arr, 0, n - 1);

            if (n == 1)
                return arr[0];

            int best = int.MaxValue;
            for (int i = 1; i <= n; i++)
                best = Math.Min(best, Math.Max(DivideAndConquerApproach(arr, i, k - 1),
                                                   sum(arr, i, n - 1)));

            return best;
        }
        static int DynamicProgrammingApproach(int[] arr, int n, int k)
        {
            int[,] dp = new int[k + 1, n + 1];

            for (int i = 1; i <= n; i++)
                dp[1, i] = sum(arr, 0, i - 1);
            for (int i = 1; i <= k; i++)
                dp[i, 1] = arr[0];
            for (int i = 2; i <= k; i++)
            { 
                for (int j = 2; j <= n; j++)
                {
                    int best = int.MaxValue;
                    for (int p = 1; p <= j; p++)
                        best = Math.Min(best, Math.Max(dp[i - 1, p],
                                              sum(arr, p, j - 1)));

                    dp[i, j] = best;
                }
            }

            return dp[k, n];
        }

        public static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            
            int k = int.Parse(Console.ReadLine());
            Stopwatch stopwatch = new Stopwatch();
            Stopwatch stopwatch2 = new Stopwatch();

            stopwatch.Start();
            Console.WriteLine(DivideAndConquerApproach(arr, n, k));
            stopwatch.Stop();

            stopwatch2.Start();
            Console.WriteLine(DynamicProgrammingApproach(arr, n, k)); 
            stopwatch2.Stop();

            if (stopwatch.ElapsedMilliseconds > stopwatch2.ElapsedMilliseconds)
            {
                Console.WriteLine("Divide And Conquer Approach Wins");
            }
            else
            {
                Console.WriteLine("Dynamic Programming Approach Wins");
            }
            
           
        }
    }
}
