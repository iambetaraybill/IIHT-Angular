﻿using System;
using System.Collections.Generic;

namespace Assignment1
{
    class UniqueRandomNumbers
    {
        public static List<int> RandomUniqueList()
        { 
        List<int> randomList = new List<int>();
        Random a = new Random();
        int MyNumber = 0;
            for(int i = 0; i<10; i++)
            {
                MyNumber = a.Next(0, 30);
                if (!randomList.Contains(MyNumber))
                {
                    randomList.Add(MyNumber);
                }
               
            }
            return randomList;
        }
        static void Main(string[] args)
        {
            List<int> uniqueRandomList = UniqueRandomNumbers.RandomUniqueList();
            foreach(int i in uniqueRandomList)
            {
                Console.Write(i.ToString() + " ");
            }

        }
    }
}
