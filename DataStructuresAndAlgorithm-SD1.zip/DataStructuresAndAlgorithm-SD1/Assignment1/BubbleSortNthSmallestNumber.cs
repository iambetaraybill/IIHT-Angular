﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    class BubbleSortNthSmallestNumber
    {
        public static int BubbleSortNthSmallest(int[] arr, int n)
        {
            //Bubble Sort logic below
            int temp;
            for (int j = 0; j <= arr.Length - 2; j++)
            {
                for (int i = 0; i <= arr.Length - 2; i++)
                {
                    if (arr[i] > arr[i + 1])
                    {
                        temp = arr[i + 1];
                        arr[i + 1] = arr[i];
                        arr[i] = temp;
                    }
                }
            }
                return arr[n - 1];
        }

        public static void Main(string[] args)
        {
            int[] arr = new int[] { 12, 3, 5, 7, 19, 67, 77, 0, };
            Console.WriteLine("Enter the n'th value to find nth smallest for array [12, 3, 5, 7, 19, 67, 77, 0,]");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.Write("n'th smallest element is " + BubbleSortNthSmallest(arr, n));
        }
    }
}
