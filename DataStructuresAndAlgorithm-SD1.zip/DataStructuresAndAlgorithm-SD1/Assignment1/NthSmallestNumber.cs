﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    class NthSmallestNumber
    {
        public static int NthSmallest(int[] arr, int k)
        {
            Array.Sort(arr);
            return arr[k - 1];
        }

        public static void Main()
        {
            int[] arr = new int[] { 12, 3, 5, 7, 19,67,77,0, };
            Console.WriteLine("Enter the n'th value to find nth smallest for array [12, 3, 5, 7, 19, 67, 77, 0,]");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.Write("n'th smallest element is " + NthSmallest(arr, n));
        }
    }
}
