﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace Assignment1
{
    class Question5_And_Ouestion6_Combined
    {
        public static List<int> RandomUniqueList(int limit)
        {
            List<int> randomList = new List<int>();
            Random a = new Random();
            int MyNumber = 0;
            for (int i = 0; i < 10; i++)
            {
                MyNumber = a.Next(0, limit);
                if (!randomList.Contains(MyNumber))
                {
                    randomList.Add(MyNumber);
                }

            }
            return randomList;
        }
        public static int BubbleSortNthSmallest(int[] arr, int n)
        {
            //Bubble Sort logic below
            int temp;
            for (int j = 0; j <= arr.Length - 2; j++)
            {
                for (int i = 0; i <= arr.Length - 2; i++)
                {
                    if (arr[i] > arr[i + 1])
                    {
                        temp = arr[i + 1];
                        arr[i + 1] = arr[i];
                        arr[i] = temp;
                    }
                }
            }
            return arr[n - 1];
        }
        static public int Partition(int[] arr, int left, int right)
        {
            int pivot;
            pivot = arr[left];
            while (true)
            {
                while (arr[left] < pivot)
                {
                    left++;
                }
                while (arr[right] > pivot)
                {
                    right--;
                }
                if (left < right)
                {
                    int temp = arr[right];
                    arr[right] = arr[left];
                    arr[left] = temp;
                }
                else
                {
                    return right;
                }
            }
        }
        public static int QuickSortNthSmallest(int[] arr, int left, int right, int n)
        {
            //Quick Sort logic below
            int pivot;
            if (left < right)
            {
                pivot = Partition(arr, left, right);
                if (pivot > 1)
                {
                    QuickSortNthSmallest(arr, left, pivot - 1, n);
                }
                if (pivot + 1 < right)
                {
                    QuickSortNthSmallest(arr, pivot + 1, right, n);
                }
            }
            return arr[n - 1];
        }
        static void Main(string[] args)
        {
            List<int> uniqueRandomList1 = Question5_And_Ouestion6_Combined.RandomUniqueList(100);
            List<int> uniqueRandomList2 = Question5_And_Ouestion6_Combined.RandomUniqueList(1000);
            List<int> uniqueRandomList3 = Question5_And_Ouestion6_Combined.RandomUniqueList(10000);
            int n = Convert.ToInt32(Console.ReadLine());
            Stopwatch stopwatch = new Stopwatch();
            Stopwatch stopwatch2 = new Stopwatch();

            stopwatch.Start();
            Console.WriteLine(" n'th smallest element for 100 " + BubbleSortNthSmallest(uniqueRandomList1.ToArray(), n));
            stopwatch.Stop();
            stopwatch2.Start();
            Console.WriteLine(" n'th smallest element for 100 " + QuickSortNthSmallest(uniqueRandomList1.ToArray(), 0, uniqueRandomList1.ToArray().Length - 1, n));
            stopwatch2.Stop();
            if(stopwatch.ElapsedMilliseconds > stopwatch2.ElapsedMilliseconds)
            {
                Console.WriteLine("Bubble Sort Wins");
            }
            else
            {
                Console.WriteLine("Quick Sort Wins");
            }
            stopwatch.Start();
            Console.WriteLine(" n'th smallest element for 1000 " + BubbleSortNthSmallest(uniqueRandomList2.ToArray(), n));
            stopwatch.Stop();
            stopwatch2.Start();
            Console.WriteLine(" n'th smallest element for 1000 " + QuickSortNthSmallest(uniqueRandomList2.ToArray(), 0, uniqueRandomList1.ToArray().Length - 1, n));
            stopwatch2.Stop();
            if (stopwatch.ElapsedMilliseconds > stopwatch2.ElapsedMilliseconds)
            {
                Console.WriteLine("Bubble Sort Wins");
            }
            else
            {
                Console.WriteLine("Quick Sort Wins");
            }
            stopwatch.Start();
            Console.WriteLine(" n'th smallest element for 10000 " + BubbleSortNthSmallest(uniqueRandomList3.ToArray(), n));
            stopwatch.Stop();
            stopwatch2.Start();
            Console.WriteLine(" n'th smallest element for 10000 " + QuickSortNthSmallest(uniqueRandomList3.ToArray(), 0, uniqueRandomList1.ToArray().Length - 1, n));
            stopwatch2.Stop();
            if (stopwatch.ElapsedMilliseconds > stopwatch2.ElapsedMilliseconds)
            {
                Console.WriteLine("Bubble Sort Wins");
            }
            else
            {
                Console.WriteLine("Quick Sort Wins");
            }
        }
    }
}
