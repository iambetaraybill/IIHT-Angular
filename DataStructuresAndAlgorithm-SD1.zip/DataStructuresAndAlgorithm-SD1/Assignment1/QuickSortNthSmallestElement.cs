﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    class QuickSortNthSmallestElement
    {
        static public int Partition(int[] arr, int left, int right)
        {
            int pivot;
            pivot = arr[left];
            while (true)
            {
                while (arr[left] < pivot)
                {
                    left++;
                }
                while (arr[right] > pivot)
                {
                    right--;
                }
                if (left < right)
                {
                    int temp = arr[right];
                    arr[right] = arr[left];
                    arr[left] = temp;
                }
                else
                {
                    return right;
                }
            }
        }
        public static int QuickSortNthSmallest(int[] arr, int left, int right, int n)
        {
            //Quick Sort logic below
            int pivot;
            if (left < right)
            {
                pivot = Partition(arr, left, right);
                if (pivot > 1)
                {
                    QuickSortNthSmallest(arr, left, pivot - 1,n);
                }
                if (pivot + 1 < right)
                {
                    QuickSortNthSmallest(arr, pivot + 1, right,n);
                }
            }
            return arr[n - 1];
        }
        public static void Main(string[] args)
        {
            int[] arr = new int[] { 12, 3, 5, 7, 19, 67, 77, 0, };
            Console.WriteLine("Enter the n'th value to find nth smallest for array [12, 3, 5, 7, 19, 67, 77, 0,]");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.Write("n'th smallest element is " + QuickSortNthSmallest(arr, 0, arr.Length-1,n));
        }
    }
}
